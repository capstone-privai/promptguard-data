# Codex 재생(replay) 평가셋 키트 v0

진짜 Codex CLI를 돌리되, 모델 자리에 "정해진 명령만 순서대로 내보내는 가짜 모델"을 꽂아서
**형식이 100% 진짜인 Codex 세션 기록(rollout)** 과 **비밀값의 정확한 위치(정답 span)** 를 함께 만든다.
돈이 안 들고(실제 모델 호출 없음), 비밀은 전부 매번 새로 만든 가짜값이다.

## 구성

- `replay_server.py` — 가짜 모델 서버(OpenAI Responses API 흉내). 요청이 올 때마다 시나리오의 다음 명령을 `exec_command` 호출로 돌려주고, 명령이 끝나면 마지막 답변을 보낸다. Codex가 보낸 요청 본문은 전부 `requests.jsonl`에 남는다(= 모델이 실제로 받은 입력).
- `build_session.py` — 세션 1개 생성. ① 가짜 비밀 생성 → ② 비밀을 심은 작은 저장소 생성(.env, docker-compose, k8s secret(base64), 로그(URL 인코딩된 DSN, Bearer 토큰, JWT), 디버그 출력하는 스크립트, git 기록에만 남은 AWS 키, 프로세스 환경변수) → ③ `codex exec` 실행 → ④ rollout에서 정답 span 추출 → ⑤ 정답 span이 실제 요청 본문에도 있는지 대조.
- `score_metric1.py` — 지표 1 채점(엄격 span 성공률 + 글자 단위 Precision). 기준선: Codex 내장 정규식 4개, detect-secrets, CredSweeper(`run_credsweeper.py`로 먼저 돌려 둠).
- `run_credsweeper.py` — 모델이 받는 텍스트 칸마다 파일로 떨궈서 CredSweeper를 한 번에 돌리고, 결과를 글자 위치로 되돌린다.
- `example_s1/` — 생성 예시 1개(scenario.json, secrets.json, gold_spans.jsonl, rollout.jsonl).

## 실행

```bash
npm install -g @openai/codex          # 확인한 버전: codex-cli 0.160.0
python3 build_session.py --seed 1 --out out/s1
python3 build_session.py --seed 2 --out out/s2
pip install detect-secrets
python3 -m venv csenv && csenv/bin/pip install credsweeper   # run_credsweeper.py 안의 경로 맞추기
python3 run_credsweeper.py out/s1 out/s2
python3 score_metric1.py out/s1 out/s2
```

## 정답 span 형식 (gold_spans.jsonl 한 줄 = 비밀 1회 등장)

| 필드 | 뜻 |
|---|---|
| `rollout_line` | rollout.jsonl의 몇 번째 줄(0부터) |
| `item_type`, `role` | `message`(user) / `function_call` / `function_call_output` |
| `field` | 그 줄 안의 어느 칸인지 (`payload.output`, `payload.content[1].text`, `payload.arguments`) |
| `start`, `end` | 그 칸 문자열 안의 글자 위치(0부터, end 미포함) |
| `secret_id`, `type` | 어떤 비밀인지, 후보 형식 v1의 type 8종 중 무엇인지 |
| `form` | `raw`(그대로) / `base64` / `url`(URL 인코딩) |
| `text` | 확인용 실제 문자열 |

라벨은 **모델에게 가는 줄(response_item)에만** 단다. 같은 비밀이 `event_msg`(화면 표시용) 줄에도 복사돼 있지만, 그건 모델 입력이 아니다(rollout 파일 자체는 따로 보호해야 함).

## 알려진 한계 (v0)

- 명령 순서를 사람이 정했다. 진짜 모델은 `.env`를 통째로 `cat`하기보다 `rg`로 필요한 키만 찾는 경우가 많다(10/1 실험).
- 가짜 모델에게는 일반 함수 도구(`exec_command`)가 제공된다. 최신 진짜 모델(gpt-6.1-sol)은 코드 모드(`exec` + JS)로 부르고, 출력 머리말도 다르다(`Script completed`…). 이 형식은 아직 안 만든다.
- 저장소 템플릿이 1종이라 세션끼리 구조가 같다(템플릿 누수). 지금 숫자는 배관 점검용이지 결과가 아니다.
- 어려운 음성(가리면 안 되는 것)이 적어서 Precision이 쉽게 1.0이 나온다.
